import nodemailer from 'nodemailer';
import { config } from '../config/env.js';

// Gmail SMTP configuration for AWS deployment
// Note: Gmail requires App Password, not regular password
const gmailUser = config.email.user;
const gmailAppPassword = config.email.pass;
const gmailFrom = config.email.from || 'noreply@gmail.com';

// Create Gmail transporter using App Password
const gmailTransporter = gmailUser && gmailAppPassword ? nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: gmailUser,
    pass: gmailAppPassword
  }
}) : null;

/**
 * Send email via Gmail
 * @param {string} to - Recipient email
 * @param {string} subject - Email subject
 * @param {string} html - Email HTML body
 */
const sendViaGmail = async (to, subject, html) => {
  const mailOptions = {
    from: `"CollegeAnon" <${gmailFrom}>`,
    to: to,
    subject: subject,
    html: html
  };

  return await gmailTransporter.sendMail(mailOptions);
};

/**
 * Send verification email using Gmail
 * @param {string} email - Recipient email
 * @param {string} token - Verification token
 */
export const sendVerificationEmail = async (email, token) => {
  const verificationUrl = `${config.frontendUrl}/verify-email/${token}`;
  
  // Use Gmail if configured
  if (gmailTransporter) {
    await sendViaGmail(
      email,
      'Verify Your CollegeAnon Account',
      `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4F46E5;">Welcome to CollegeAnon!</h2>
          <p>Thank you for registering. Please verify your email address to activate your account.</p>
          <p style="margin: 30px 0;">
            <a href="${verificationUrl}" 
               style="background-color: #4F46E5; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 6px; display: inline-block;">
              Verify Email Address
            </a>
          </p>
          <p style="color: #6B7280; font-size: 14px;">
            If the button doesn't work, copy and paste this link into your browser:<br>
            <a href="${verificationUrl}" style="color: #4F46E5;">${verificationUrl}</a>
          </p>
          <p style="color: #6B7280; font-size: 12px; margin-top: 30px;">
            This verification link will expire in 24 hours.<br>
            If you didn't register for CollegeAnon, please ignore this email.
          </p>
        </div>
      `
    );
    console.log(`Verification email sent via Gmail to ${email}`);
    return;
  }
  
  console.warn('Gmail not configured. Skipping email send.');
  return { messageId: null };
};

/**
 * Send password reset email using Gmail
 * @param {string} email - Recipient email
 * @param {string} token - Reset password token
 */
export const sendPasswordResetEmail = async (email, token) => {
  const resetUrl = `${config.frontendUrl}/reset-password/${token}`;
  
  // Use Gmail if configured
  if (gmailTransporter) {
    await sendViaGmail(
      email,
      'Reset Your CollegeAnon Password',
      `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4F46E5;">Password Reset Request</h2>
          <p>You requested to reset your password. Click the button below to create a new password.</p>
          <p style="margin: 30px 0;">
            <a href="${resetUrl}" 
               style="background-color: #4F46E5; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 6px; display: inline-block;">
              Reset Password
            </a>
          </p>
          <p style="color: #6B7280; font-size: 14px;">
            If the button doesn't work, copy and paste this link into your browser:<br>
            <a href="${resetUrl}" style="color: #4F46E5;">${resetUrl}</a>
          </p>
          <p style="color: #DC2626; font-size: 14px; margin-top: 20px;">
            <strong>Security Note:</strong> If you didn't request this password reset, 
            please ignore this email and your password will remain unchanged.
          </p>
          <p style="color: #6B7280; font-size: 12px; margin-top: 30px;">
            This reset link will expire in 1 hour.
          </p>
        </div>
      `
    );
    console.log(`Password reset email sent via Gmail to ${email}`);
    return;
  }
  
  console.warn('Gmail not configured. Skipping email send.');
  return { messageId: null };
};

/**
 * Verify email configuration
 */
export const verifyEmailConfig = async () => {
  if (!gmailTransporter) {
    console.warn('Gmail not configured');
    return;
  }
  
  try {
    await gmailTransporter.verify();
    console.log('Gmail is configured and working');
  } catch (error) {
    console.error('Gmail configuration error:', error);
  }
};

export default {
  sendVerificationEmail,
  sendPasswordResetEmail,
  verifyEmailConfig,
};
